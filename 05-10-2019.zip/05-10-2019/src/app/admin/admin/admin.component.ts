import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  rightSideNav = true ;
  constructor() { }

  ngOnInit() {
  }
  sideNavBtnToggle(){
    if(this.rightSideNav == false)
    {
      this.rightSideNav  = true;
    }
    else{
      this.rightSideNav  = false;
    } 
    //console.log(this.rightSideNav);
}

}
