import { Component, OnInit } from '@angular/core';
import {trigger,state,style,animate,transition} from '@angular/animations';
import {FormGroup,  FormBuilder,  Validators} from '@angular/forms';
import { ServicesService} from '../services.service';
import{Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  angForm: FormGroup;
  loginstatus:any;
  errormsg:string;
  logindata={}
  constructor(private fb: FormBuilder,private ls:ServicesService,private route:Router) {this.createForm(); }
  createForm() {
    this.angForm = this.fb.group({
      email: ['', Validators.required ],
      password: ['', Validators.required ]
    });
  }

  ngOnInit() {
    this.ls.logout();
  }
  login(email,password)
  {
    this.ls.login(email,password).subscribe((data: any) => {
      this.loginstatus = data;
      //console.log(this.loginstatus);
      if(this.loginstatus['message']=='Succuss')
      {
        localStorage.setItem('token',this.loginstatus['token']);
        localStorage.setItem('user_type',this.loginstatus['usertype']);
        localStorage.setItem('assign_role',this.loginstatus['assign_role']);
        localStorage.setItem('org_id',this.loginstatus['org_id']);
       
        this.route.navigate(["/admin"]);

      }else{
        this.errormsg=this.loginstatus['message'];
        
      }  
    })
    
    
  
    
  }

}
